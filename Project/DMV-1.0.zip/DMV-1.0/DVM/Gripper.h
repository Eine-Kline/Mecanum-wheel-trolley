#ifndef __GRIPPER_H__
#define __GRIPPER_H__


#include "main.h"
#include "gpio.h"
#include "stm32f1xx_hal_gpio.h"
#include "tim.h"

void setGripper(char action);

#endif